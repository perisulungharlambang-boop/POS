import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.tokosaya.pos',
  appName: 'POS Toko Saya',
  webDir: 'dist'
};

export default config;

import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import Kasir from './pages/Kasir';
import Produk from './pages/Produk';
import Kategori from './pages/Kategori';
import Transaksi from './pages/Transaksi';
import Laporan from './pages/Laporan';
import PengaturanToko from './pages/PengaturanToko';
import PageNotFound from './lib/PageNotFound';

// Kita buat AuthenticatedApp menjadi sederhana tanpa cek login server
const AuthenticatedApp = () => {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<Dashboard />} />
        <Route path="/kasir" element={<Kasir />} />
        <Route path="/produk" element={<Produk />} />
        <Route path="/kategori" element={<Kategori />} />
        <Route path="/transaksi" element={<Transaksi />} />
        <Route path="/laporan" element={<Laporan />} />
        <Route path="/pengaturan-toko" element={<PengaturanToko />} />
      </Route>
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};

function App() {
  return (
    <Router>
      <AuthenticatedApp />
    </Router>
  );
}

export default App;
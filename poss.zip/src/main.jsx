import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import './index.css'
import { registerSW } from 'virtual:pwa-register'

// Register service worker
registerSW({ immediate: true })

const appName = import.meta.env.VITE_APP_NAME || 'TokoKu'
document.title = `${appName} — POS`

ReactDOM.createRoot(document.getElementById('root')).render(
  <App />
)


import { useEffect, useRef, useState } from 'react';
import { Html5Qrcode } from 'html5-qrcode';
import { X, RefreshCw, Camera } from 'lucide-react';
import { Button } from './ui/button';

const BarcodeScanner = ({ onDetected, onClose }) => {
  const scannerRef = useRef(null);
  const html5QrCodeRef = useRef(null);
  const [error, setError] = useState(null);
  const [isInitializing, setIsInitializing] = useState(true);

  const stopScanner = async () => {
    if (html5QrCodeRef.current && html5QrCodeRef.current.isScanning) {
      try {
        await html5QrCodeRef.current.stop();
        html5QrCodeRef.current.clear();
      } catch (err) {
        console.error('Gagal menghentikan scanner:', err);
      }
    }
  };

  const startScanner = async () => {
    setError(null);
    setIsInitializing(true);
    
    try {
      await stopScanner();

      if (!html5QrCodeRef.current) {
        html5QrCodeRef.current = new Html5Qrcode('qr-reader');
      }

      const config = {
        fps: 10,
        qrbox: { width: 250, height: 250 },
        aspectRatio: 1.0
      };

      await html5QrCodeRef.current.start(
        { facingMode: 'environment' },
        config,
        (decodedText) => {
          onDetected(decodedText);
          stopScanner();
        },
        (errorMessage) => {
          // Abaikan error saat mencari barcode (normal)
        }
      );
      setIsInitializing(false);
    } catch (err) {
      console.error('Error saat memulai kamera:', err);
      setError('Gagal mengakses kamera. Pastikan izin kamera diberikan dan Anda menggunakan HTTPS.');
      setIsInitializing(false);
    }
  };

  useEffect(() => {
    startScanner();
    return () => {
      stopScanner();
    };
  }, []);

  return (
    <div className="fixed inset-0 z-[100] bg-black flex flex-col">
      <div className="flex items-center justify-between p-4 text-white z-10 bg-black/50">
        <h2 className="text-lg font-semibold">Scan Barcode</h2>
        <button onClick={onClose} className="p-2 rounded-full bg-white/10 hover:bg-white/20 transition-colors">
          <X className="h-6 w-6" />
        </button>
      </div>

      <div className="flex-1 relative flex items-center justify-center">
        <div id="qr-reader" className="w-full h-full max-h-[70vh]"></div>
        
        {isInitializing && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-black text-white gap-3">
            <RefreshCw className="h-10 w-10 animate-spin text-primary" />
            <p className="text-sm opacity-70">Memulai kamera...</p>
          </div>
        )}

        {error && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/90 text-white p-6 text-center gap-4">
            <div className="p-4 rounded-full bg-destructive/20">
              <Camera className="h-12 w-12 text-destructive" />
            </div>
            <p className="text-sm text-destructive font-medium">{error}</p>
            <Button onClick={startScanner} variant="outline" className="gap-2 border-white/20 hover:bg-white/10">
              <RefreshCw className="h-4 w-4" /> Coba Lagi
            </Button>
          </div>
        )}
      </div>

      <div className="p-8 bg-black/50 text-center text-white/60 text-xs">
        Arahkan kamera ke barcode produk
      </div>
    </div>
  );
};

export default BarcodeScanner;

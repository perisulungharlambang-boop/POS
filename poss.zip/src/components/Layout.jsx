import { Outlet, Link, useLocation } from 'react-router-dom';
import { LayoutDashboard, ShoppingCart, Package, History, BarChart3, Store, Settings } from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';

const navItems = [
  { path: '/', label: 'Dashboard', icon: LayoutDashboard },
  { path: '/kasir', label: 'Kasir', icon: ShoppingCart },
  { path: '/produk', label: 'Produk', icon: Package },
  { path: '/transaksi', label: 'Transaksi', icon: History },
  { path: '/laporan', label: 'Laporan', icon: BarChart3 },
  { path: '/pengaturan-toko', label: 'Pengaturan', icon: Settings },
];

const pageOrder = ['/', '/kasir', '/produk', '/transaksi', '/laporan', '/pengaturan-toko'];

const pageVariants = {
  enter: (direction) => ({
    x: direction > 0 ? '100%' : '-100%',
    opacity: 0,
  }),
  center: {
    x: 0,
    opacity: 1,
  },
  exit: (direction) => ({
    x: direction < 0 ? '100%' : '-100%',
    opacity: 0,
  }),
};

const pageTransition = {
  type: 'tween',
  ease: [0.25, 0.46, 0.45, 0.94],
  duration: 0.28,
};

export default function Layout() {
  const location = useLocation();
  const currentIndex = pageOrder.indexOf(location.pathname);
  const appName = import.meta.env.VITE_APP_NAME || 'TokoKu';

  return (
    <div className="min-h-screen flex flex-col bg-background overflow-hidden">
      {/* Top Header */}
      <header
        className="fixed top-0 left-0 right-0 z-40 bg-card/95 backdrop-blur-sm border-b border-border"
        style={{ paddingTop: 'env(safe-area-inset-top)' }}
      >
        <div className="flex items-center gap-3 px-4 h-14">
          <div className="h-8 w-8 rounded-xl bg-primary flex items-center justify-center flex-shrink-0">
            <Store className="h-4 w-4 text-primary-foreground" />
          </div>
          <div>
            <h1 className="font-bold text-base leading-tight">{appName}</h1>
            <p className="text-[10px] text-muted-foreground leading-tight">Sistem Kasir</p>
          </div>
        </div>
      </header>

      {/* Page Content with Framer Motion transitions */}
      <main
        className="flex-1 overflow-hidden"
        style={{
          paddingTop: 'calc(env(safe-area-inset-top) + 3.5rem)',
          paddingBottom: 'calc(env(safe-area-inset-bottom) + 4rem)',
        }}
      >
        <AnimatePresence initial={false} custom={currentIndex} mode="wait">
          <motion.div
            key={location.pathname}
            custom={currentIndex}
            variants={pageVariants}
            initial="enter"
            animate="center"
            exit="exit"
            transition={pageTransition}
            className="w-full h-full overflow-y-auto"
          >
            <div className="p-4 md:p-6">
              <Outlet />
            </div>
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Bottom Navigation Bar */}
      <nav
        className="fixed bottom-0 left-0 right-0 z-40 bg-card/95 backdrop-blur-sm border-t border-border"
        style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
      >
        <div className="flex items-stretch h-16">
          {navItems.map(item => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className="flex-1 flex flex-col items-center justify-center gap-1 select-none transition-colors duration-150"
                style={{ WebkitTapHighlightColor: 'transparent' }}
              >
                <div className={`flex items-center justify-center h-8 w-8 rounded-xl transition-all duration-200 ${isActive ? 'bg-primary/10 scale-110' : ''}`}>
                  <Icon className={`h-5 w-5 transition-colors duration-200 ${isActive ? 'text-primary' : 'text-muted-foreground'}`} />
                </div>
                <span className={`text-[10px] font-medium transition-colors duration-200 ${isActive ? 'text-primary' : 'text-muted-foreground'}`}>
                  {item.label}
                </span>
              </Link>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
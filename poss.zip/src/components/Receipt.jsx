import { useRef } from 'react';
import { formatRupiah } from '../lib/formatCurrency';
import { Printer, MessageCircle, Mail, X } from 'lucide-react';
import { Button } from './ui/button';
import moment from 'moment';
import { getStoreSettings } from '../lib/storeSettings';

const paymentLabels = { cash: 'Tunai', transfer: 'Transfer', qris: 'QRIS' };

export default function Receipt({ transaction, onClose }) {
  const receiptRef = useRef(null);

  if (!transaction) return null;

  const settings = getStoreSettings();
  const storeName = settings.storeName;
  const storeAddress = settings.storeAddress;
  const phoneNumber = settings.phoneNumber;
  const receiptFooter = settings.receiptFooter;
  const date = moment(transaction.created_date || new Date()).format('DD/MM/YYYY HH:mm');

  const receiptText = () => {
    const lines = [
      `*${storeName}*`,
      `${storeAddress}`,
      `--------------------------------`,
      `No: ${transaction.invoice_number}`,
      `Tgl: ${date}`,
      `--------------------------------`,
      ...(transaction.items || []).map(
        item => `${item.product_name}\n  ${item.quantity} x ${formatRupiah(item.price)} = ${formatRupiah(item.subtotal)}`
      ),
      `--------------------------------`,
      `*Total: ${formatRupiah(transaction.total)}*`,
      `Bayar (${paymentLabels[transaction.payment_method] || transaction.payment_method}): ${formatRupiah(transaction.payment_amount)}`,
      ...(transaction.payment_method === 'cash'
        ? [`Kembalian: ${formatRupiah(transaction.change_amount)}`]
        : []),
      `--------------------------------`,
      ...(phoneNumber ? [`Telp: ${phoneNumber}`] : []),
      `${receiptFooter} 🙏`,
    ];
    return lines.join('\n');
  };

  const handlePrint = () => {
    const printContent = receiptRef.current.innerHTML;
    const win = window.open('', '_blank', 'width=400,height=600');
    win.document.write(`
      <html>
        <head>
          <title>Struk - ${transaction.invoice_number}</title>
          <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body {
              font-family: 'Courier New', monospace;
              font-size: 12px;
              width: 80mm;
              padding: 4mm;
              color: #000;
            }
            .center { text-align: center; }
            .bold { font-weight: bold; }
            .divider { border-top: 1px dashed #000; margin: 4px 0; }
            .row { display: flex; justify-content: space-between; margin: 2px 0; }
            .item-name { font-weight: bold; margin-top: 4px; }
            .item-detail { padding-left: 8px; color: #333; }
            .total-row { font-size: 14px; font-weight: bold; }
            .footer { text-align: center; margin-top: 8px; font-size: 11px; }
          </style>
        </head>
        <body>${printContent}</body>
      </html>
    `);
    win.document.close();
    win.focus();
    setTimeout(() => { win.print(); win.close(); }, 300);
  };

  const handleWhatsApp = () => {
    const text = encodeURIComponent(receiptText());
    window.open(`https://wa.me/?text=${text}`, '_blank');
  };

  const handleEmail = () => {
    const subject = encodeURIComponent(`Struk Belanja ${transaction.invoice_number} - ${storeName}`);
    const body = encodeURIComponent(receiptText().replace(/\*/g, ''));
    window.open(`mailto:?subject=${subject}&body=${body}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 flex items-end sm:items-center justify-center p-4">
      <div className="bg-card w-full max-w-sm rounded-3xl overflow-hidden shadow-2xl"
        style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}>
        {/* Header */}
        <div className="flex items-center justify-between px-5 pt-5 pb-3 border-b border-border">
          <h2 className="font-bold text-base">Transaksi Berhasil ✅</h2>
          <button onClick={onClose} className="h-8 w-8 rounded-full hover:bg-secondary flex items-center justify-center select-none" style={{ WebkitUserSelect: 'none' }}>
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Thermal Receipt Preview */}
        <div className="px-5 py-4 overflow-y-auto max-h-[55vh]">
          <div
            ref={receiptRef}
            className="bg-white text-black rounded-xl p-4 font-mono text-[11px] leading-relaxed"
            style={{ fontFamily: "'Courier New', monospace" }}
          >
            <div className="center bold text-sm text-center font-bold mb-1">{storeName}</div>
            <div className="text-center text-[10px] text-gray-600 mb-2">{storeAddress}</div>
            {phoneNumber && <div className="text-center text-[10px] text-gray-600 mb-2">Telp: {phoneNumber}</div>}
            <div className="border-t border-dashed border-gray-400 my-2" />
            <div className="flex justify-between text-[10px]">
              <span>No: {transaction.invoice_number}</span>
            </div>
            <div className="flex justify-between text-[10px] mb-2">
              <span>Tgl: {date}</span>
            </div>
            <div className="border-t border-dashed border-gray-400 my-2" />
            {(transaction.items || []).map((item, i) => (
              <div key={i} className="mb-2">
                <div className="font-bold text-[11px]">{item.product_name}</div>
                <div className="flex justify-between text-[10px] text-gray-600 pl-2">
                  <span>{item.quantity} x {formatRupiah(item.price)}</span>
                  <span>{formatRupiah(item.subtotal)}</span>
                </div>
              </div>
            ))}
            <div className="border-t border-dashed border-gray-400 my-2" />
            <div className="flex justify-between font-bold text-[13px] mb-1">
              <span>TOTAL</span>
              <span>{formatRupiah(transaction.total)}</span>
            </div>
            <div className="flex justify-between text-[10px]">
              <span>Bayar ({paymentLabels[transaction.payment_method] || transaction.payment_method})</span>
              <span>{formatRupiah(transaction.payment_amount)}</span>
            </div>
            {transaction.payment_method === 'cash' && (
              <div className="flex justify-between text-[10px] font-semibold">
                <span>Kembalian</span>
                <span>{formatRupiah(transaction.change_amount)}</span>
              </div>
            )}
            <div className="border-t border-dashed border-gray-400 my-2" />
            <div className="text-center text-[10px] text-gray-500">{receiptFooter}</div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="px-5 pb-5 pt-3 space-y-2">
          <Button
            onClick={handlePrint}
            className="w-full rounded-xl h-11 font-semibold select-none gap-2"
            style={{ WebkitUserSelect: 'none' }}
          >
            <Printer className="h-4 w-4" /> Cetak Struk
          </Button>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={handleWhatsApp}
              className="flex items-center justify-center gap-2 h-11 rounded-xl bg-[#25D366] text-white text-sm font-semibold select-none active:opacity-80 transition-opacity"
              style={{ WebkitUserSelect: 'none' }}
            >
              <MessageCircle className="h-4 w-4" /> WhatsApp
            </button>
            <button
              onClick={handleEmail}
              className="flex items-center justify-center gap-2 h-11 rounded-xl bg-secondary text-secondary-foreground text-sm font-semibold select-none active:opacity-80 transition-opacity border border-border"
              style={{ WebkitUserSelect: 'none' }}
            >
              <Mail className="h-4 w-4" /> Email
            </button>
          </div>
          <button
            onClick={onClose}
            className="w-full h-10 rounded-xl text-sm text-muted-foreground hover:bg-secondary transition-colors select-none"
            style={{ WebkitUserSelect: 'none' }}
          >
            Transaksi Baru
          </button>
        </div>
      </div>
    </div>
  );
}
export default function StatCard({ icon: Icon, label, value, subValue, color = "primary" }) {
  return (
    <div className="bg-card rounded-2xl border border-border p-5 hover:shadow-lg transition-shadow duration-300">
      <div className="flex items-start justify-between">
        <div className="space-y-2">
          <p className="text-sm text-muted-foreground font-medium">{label}</p>
          <p className="text-2xl font-bold tracking-tight">{value}</p>
          {subValue && <p className="text-xs text-muted-foreground">{subValue}</p>}
        </div>
        <div className={`h-12 w-12 rounded-2xl bg-primary/10 flex items-center justify-center`}>
          <Icon className="h-6 w-6 text-primary" />
        </div>
      </div>
    </div>
  );
}
import { useState, useEffect, useCallback, useRef } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { base44 } from '../api/base44Client';
import { formatRupiah } from '../lib/formatCurrency';
import { Plus, Search, Pencil, Trash2, Package, ScanLine } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Label } from '../components/ui/label';
import { toast } from 'sonner';
import PullToRefresh from '../components/PullToRefresh';
import BarcodeScanner from '../components/BarcodeScanner';

export default function Produk() {
  const location = useLocation();
  const navigate = useNavigate();
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);
  const [scannerOpen, setScannerOpen] = useState(false);
  const [form, setForm] = useState({ name: '', price: '', cost_price: '', stock: '', category_name: '', barcode: '', unit: 'pcs' });
  const barcodeInputRef = useRef(null);

  const loadData = useCallback(async () => {
    const [prods, cats] = await Promise.all([
      base44.entities.Product.list('-created_date', 200),
      base44.entities.Category.list(),
    ]);
    setProducts(prods);
    setCategories(cats);
    setLoading(false);
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  useEffect(() => {
    if (!dialogOpen) return;
    const timer = setTimeout(() => barcodeInputRef.current?.focus(), 50);
    return () => clearTimeout(timer);
  }, [dialogOpen]);

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const newBarcode = params.get('newBarcode');
    if (!newBarcode) return;
    setEditingProduct(null);
    setForm({ name: '', price: '', cost_price: '', stock: '', category_name: '', barcode: newBarcode, unit: 'pcs' });
    setDialogOpen(true);
    navigate('/produk', { replace: true });
  }, [location.search, navigate]);

  const filtered = products.filter(p =>
    p.name.toLowerCase().includes(search.toLowerCase()) || (p.barcode || '').includes(search)
  );

  const openAdd = () => {
    setEditingProduct(null);
    setForm({ name: '', price: '', cost_price: '', stock: '', category_name: '', barcode: '', unit: 'pcs' });
    setDialogOpen(true);
  };

  const openEdit = (product) => {
    setEditingProduct(product);
    setForm({
      name: product.name,
      price: product.price?.toString() || '',
      cost_price: product.cost_price?.toString() || '',
      stock: product.stock?.toString() || '',
      category_name: product.category_name || '',
      barcode: product.barcode || '',
      unit: product.unit || 'pcs',
    });
    setDialogOpen(true);
  };

  const handleSave = async () => {
    if (!form.name || !form.price || !form.stock) { toast.error('Nama, harga, dan stok wajib diisi'); return; }
    const data = {
      name: form.name,
      price: parseFloat(form.price),
      cost_price: parseFloat(form.cost_price) || 0,
      stock: parseInt(form.stock),
      category_name: form.category_name,
      barcode: form.barcode,
      unit: form.unit,
      is_active: true,
    };
    if (editingProduct) {
      await base44.entities.Product.update(editingProduct.id, data);
      toast.success('Produk diperbarui');
    } else {
      await base44.entities.Product.create(data);
      toast.success('Produk ditambahkan');
    }
    setDialogOpen(false);
    await loadData();
  };

  const handleDelete = async (id) => {
    if (!confirm('Hapus produk ini?')) return;
    await base44.entities.Product.delete(id);
    toast.success('Produk dihapus');
    await loadData();
  };

  const handleBarcodeDetected = (barcode) => {
    setScannerOpen(false);
    const product = products.find(p => p.barcode === barcode);
    if (product) {
      openEdit(product);
      toast.success(`Produk ditemukan: ${product.name}`);
    } else {
      setEditingProduct(null);
      setForm({ name: '', price: '', cost_price: '', stock: '', category_name: '', barcode: barcode, unit: 'pcs' });
      setDialogOpen(true);
      toast.info('Produk tidak ditemukan, silahkan tambah produk baru');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <PullToRefresh onRefresh={loadData}>
      <div className="space-y-4 pb-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold tracking-tight">Produk</h1>
            <p className="text-muted-foreground text-sm mt-0.5">{products.length} produk terdaftar</p>
          </div>
          <Button onClick={openAdd} className="rounded-xl select-none" style={{ WebkitUserSelect: 'none' }}>
            <Plus className="h-4 w-4 mr-1.5" /> Tambah
          </Button>
        </div>

        <div className="flex gap-2">
          <div className="relative flex-grow">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Cari atau scan produk..." value={search} onChange={e => setSearch(e.target.value)} className="pl-10 rounded-xl" />
          </div>
          <button
            type="button"
            onClick={() => setScannerOpen(true)}
            className="h-10 w-10 rounded-xl bg-secondary border border-border flex items-center justify-center flex-shrink-0 select-none active:scale-95 transition-transform"
            style={{ WebkitUserSelect: 'none' }}
            aria-label="Scan barcode pakai kamera"
          >
            <ScanLine className="h-4 w-4 text-foreground" />
          </button>
        </div>

        {/* Desktop table */}
        <div className="hidden md:block bg-card border border-border rounded-2xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border bg-secondary/50">
                  <th className="text-left text-xs font-semibold text-muted-foreground uppercase tracking-wider px-6 py-4">Produk</th>
                  <th className="text-left text-xs font-semibold text-muted-foreground uppercase tracking-wider px-6 py-4">Kategori</th>
                  <th className="text-right text-xs font-semibold text-muted-foreground uppercase tracking-wider px-6 py-4">Harga Beli</th>
                  <th className="text-right text-xs font-semibold text-muted-foreground uppercase tracking-wider px-6 py-4">Harga Jual</th>
                  <th className="text-right text-xs font-semibold text-muted-foreground uppercase tracking-wider px-6 py-4">Stok</th>
                  <th className="text-right text-xs font-semibold text-muted-foreground uppercase tracking-wider px-6 py-4">Aksi</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(product => (
                  <tr key={product.id} className="border-b border-border last:border-0 hover:bg-secondary/30 transition-colors">
                    <td className="px-6 py-4">
                      <div>
                        <p className="font-medium text-sm">{product.name}</p>
                        {product.barcode && <p className="text-xs text-muted-foreground">{product.barcode}</p>}
                      </div>
                    </td>
                    <td className="px-6 py-4 text-sm text-muted-foreground">{product.category_name || '-'}</td>
                    <td className="px-6 py-4 text-sm text-right">{formatRupiah(product.cost_price)}</td>
                    <td className="px-6 py-4 text-sm text-right font-semibold">{formatRupiah(product.price)}</td>
                    <td className="px-6 py-4 text-right">
                      <span className={`text-sm font-medium ${product.stock <= 10 ? 'text-destructive' : ''}`}>
                        {product.stock} {product.unit || 'pcs'}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <Button variant="ghost" size="icon" className="h-8 w-8 select-none" onClick={() => openEdit(product)}><Pencil className="h-4 w-4" /></Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive select-none" onClick={() => handleDelete(product.id)}><Trash2 className="h-4 w-4" /></Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Mobile card list */}
        <div className="md:hidden space-y-3">
          {filtered.map(product => (
            <div key={product.id} className="bg-card border border-border rounded-2xl p-4">
              <div className="flex items-start justify-between mb-2">
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-sm">{product.name}</p>
                  <p className="text-xs text-muted-foreground">{product.category_name || 'Uncategorized'}{product.barcode ? ` · ${product.barcode}` : ''}</p>
                </div>
                <div className="flex items-center gap-1 ml-2">
                  <button
                    onClick={() => openEdit(product)}
                    className="h-8 w-8 rounded-lg flex items-center justify-center hover:bg-secondary transition-colors select-none"
                    style={{ WebkitUserSelect: 'none' }}
                  >
                    <Pencil className="h-3.5 w-3.5 text-muted-foreground" />
                  </button>
                  <button
                    onClick={() => handleDelete(product.id)}
                    className="h-8 w-8 rounded-lg flex items-center justify-center hover:bg-destructive/10 transition-colors select-none"
                    style={{ WebkitUserSelect: 'none' }}
                  >
                    <Trash2 className="h-3.5 w-3.5 text-destructive" />
                  </button>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-2 mt-3">
                <div className="bg-secondary/50 rounded-lg p-2 text-center">
                  <p className="text-[10px] text-muted-foreground">Harga Beli</p>
                  <p className="text-xs font-semibold">{formatRupiah(product.cost_price)}</p>
                </div>
                <div className="bg-secondary/50 rounded-lg p-2 text-center">
                  <p className="text-[10px] text-muted-foreground">Harga Jual</p>
                  <p className="text-xs font-semibold text-primary">{formatRupiah(product.price)}</p>
                </div>
                <div className="bg-secondary/50 rounded-lg p-2 text-center">
                  <p className="text-[10px] text-muted-foreground">Stok</p>
                  <p className={`text-xs font-bold ${product.stock <= 10 ? 'text-destructive' : ''}`}>{product.stock} {product.unit || 'pcs'}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">
            <Package className="h-10 w-10 mx-auto mb-2 opacity-30" />
            <p className="text-sm">Tidak ada produk ditemukan</p>
          </div>
        )}
      </div>

      {/* Add/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{editingProduct ? 'Edit Produk' : 'Tambah Produk'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Nama Produk *</Label>
              <Input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} className="rounded-xl mt-1" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Harga Jual *</Label>
                <Input type="number" value={form.price} onChange={e => setForm({ ...form, price: e.target.value })} className="rounded-xl mt-1" />
              </div>
              <div>
                <Label>Harga Beli</Label>
                <Input type="number" value={form.cost_price} onChange={e => setForm({ ...form, cost_price: e.target.value })} className="rounded-xl mt-1" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Stok *</Label>
                <Input type="number" value={form.stock} onChange={e => setForm({ ...form, stock: e.target.value })} className="rounded-xl mt-1" />
              </div>
              <div>
                <Label>Satuan</Label>
                <Select value={form.unit} onValueChange={v => setForm({ ...form, unit: v })}>
                  <SelectTrigger className="rounded-xl mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {['pcs', 'kg', 'liter', 'pack', 'dus', 'lusin'].map(u => (
                      <SelectItem key={u} value={u}>{u}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label>Kategori</Label>
              <Select value={form.category_name} onValueChange={v => setForm({ ...form, category_name: v })}>
                <SelectTrigger className="rounded-xl mt-1"><SelectValue placeholder="Pilih kategori" /></SelectTrigger>
                <SelectContent>
                  {categories.map(c => (
                    <SelectItem key={c.id} value={c.name}>{c.icon} {c.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Barcode</Label>
              <div className="mt-1">
                <Input
                  ref={barcodeInputRef}
                  value={form.barcode}
                  onChange={e => setForm({ ...form, barcode: e.target.value })}
                  className="rounded-xl"
                  autoFocus
                />
              </div>
            </div>
            <Button className="w-full rounded-xl select-none" style={{ WebkitUserSelect: 'none' }} onClick={handleSave}>
              {editingProduct ? 'Simpan Perubahan' : 'Tambah Produk'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {scannerOpen && (
        <BarcodeScanner
          onDetected={handleBarcodeDetected}
          onClose={() => setScannerOpen(false)}
        />
      )}
    </PullToRefresh>
  );
}
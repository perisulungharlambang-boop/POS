import React, { useState, useEffect } from 'react';
import { base44 } from '../api/base44Client'; // Pastikan mengarah ke client lokal kita
import { LayoutGrid, ShoppingCart, Package, TrendingUp } from 'lucide-react';

const Dashboard = () => {
  const [stats, setStats] = useState({ totalSales: 0, totalOrders: 0, totalProducts: 0 });

  useEffect(() => {
    // Memanggil fungsi list() dari base44Client.js yang sudah kita buat lokal
    const loadData = async () => {
      const trx = await base44.entity('Transaction').list();
      const prd = await base44.entity('Product').list();
      
      const total = trx.reduce((acc, curr) => acc + (curr.total || 0), 0);
      
      setStats({
        totalSales: total,
        totalOrders: trx.length,
        totalProducts: prd.length
      });
    };
    loadData();
  }, []);

  return (
    <div className="p-8 space-y-8">
      <h2 className="text-2xl font-bold text-gray-800">Ringkasan Toko Hari Ini</h2>
      
      {/* Kartu Statistik Profesional */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm text-gray-500 font-medium">Penjualan Hari Ini</p>
              <h3 className="text-2xl font-black mt-1 text-green-600">Rp {stats.totalSales.toLocaleString()}</h3>
            </div>
            <div className="p-3 bg-green-50 text-green-600 rounded-2xl"><TrendingUp size={20}/></div>
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm text-gray-500 font-medium">Total Transaksi</p>
              <h3 className="text-2xl font-black mt-1 text-gray-800">{stats.totalOrders} Pesanan</h3>
            </div>
            <div className="p-3 bg-blue-50 text-blue-600 rounded-2xl"><ShoppingCart size={20}/></div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm text-gray-500 font-medium">Varian Produk</p>
              <h3 className="text-2xl font-black mt-1 text-gray-800">{stats.totalProducts} Item</h3>
            </div>
            <div className="p-3 bg-orange-50 text-orange-600 rounded-2xl"><Package size={20}/></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
import { useEffect, useState } from 'react';
import { Save, Store } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import { getStoreSettings, saveStoreSettings } from '../lib/storeSettings';

export default function PengaturanToko() {
  const [form, setForm] = useState({
    storeName: '',
    storeAddress: '',
    phoneNumber: '',
    receiptFooter: '',
  });

  useEffect(() => {
    setForm(getStoreSettings());
  }, []);

  const handleSave = () => {
    if (!form.storeName.trim()) {
      toast.error('Nama toko wajib diisi');
      return;
    }
    if (!form.storeAddress.trim()) {
      toast.error('Alamat toko wajib diisi');
      return;
    }
    saveStoreSettings(form);
    toast.success('Pengaturan toko tersimpan');
  };

  return (
    <div className="space-y-4 pb-4">
      <div>
        <h1 className="text-xl font-bold tracking-tight">Pengaturan Toko</h1>
        <p className="text-muted-foreground text-sm mt-0.5">Data ini dipakai di struk pembayaran</p>
      </div>

      <div className="bg-card border border-border rounded-2xl p-4 space-y-4">
        <div>
          <Label>Nama Toko *</Label>
          <Input
            className="rounded-xl mt-1"
            value={form.storeName}
            onChange={(e) => setForm((prev) => ({ ...prev, storeName: e.target.value }))}
            placeholder="Contoh: Toko Sembako Maju"
          />
        </div>

        <div>
          <Label>Alamat *</Label>
          <Textarea
            className="rounded-xl mt-1 min-h-20"
            value={form.storeAddress}
            onChange={(e) => setForm((prev) => ({ ...prev, storeAddress: e.target.value }))}
            placeholder="Contoh: Jl. Melati No. 7, Jakarta"
          />
        </div>

        <div>
          <Label>No Telepon</Label>
          <Input
            className="rounded-xl mt-1"
            value={form.phoneNumber}
            onChange={(e) => setForm((prev) => ({ ...prev, phoneNumber: e.target.value }))}
            placeholder="Contoh: 0812xxxxxx"
          />
        </div>

        <div>
          <Label>Pesan Penutup Struk (Footer)</Label>
          <Textarea
            className="rounded-xl mt-1 min-h-20"
            value={form.receiptFooter}
            onChange={(e) => setForm((prev) => ({ ...prev, receiptFooter: e.target.value }))}
            placeholder="Contoh: Terima kasih sudah berbelanja!"
          />
        </div>

        <Button className="w-full rounded-xl h-11 gap-2" onClick={handleSave}>
          <Save className="h-4 w-4" /> Simpan Pengaturan
        </Button>
      </div>

      <div className="bg-secondary/40 border border-border rounded-2xl p-4 text-sm text-muted-foreground">
        <div className="flex items-center gap-2 font-medium text-foreground mb-1">
          <Store className="h-4 w-4" /> Info
        </div>
        Setelah disimpan, data toko langsung dipakai saat cetak dan kirim struk.
      </div>
    </div>
  );
}

import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '../api/base44Client';
import { formatRupiah, generateInvoiceNumber } from '../lib/formatCurrency';
import { Search, Plus, Minus, Trash2, ShoppingCart, CreditCard, Banknote, QrCode, Package, ScanLine } from 'lucide-react';
import BarcodeScanner from '../components/BarcodeScanner';
import Receipt from '../components/Receipt';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../components/ui/dialog';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '../components/ui/sheet';
import { toast } from 'sonner';

export default function Kasir() {
  const navigate = useNavigate();
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [cart, setCart] = useState([]);
  const [search, setSearch] = useState('');
  const [barcodeInput, setBarcodeInput] = useState('');
  const barcodeInputRef = useRef(null);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [loading, setLoading] = useState(true);
  const [cartOpen, setCartOpen] = useState(false);
  const [paymentOpen, setPaymentOpen] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState('cash');
  const [paymentAmount, setPaymentAmount] = useState('');
  const [processing, setProcessing] = useState(false);
  const [receiptOpen, setReceiptOpen] = useState(false);
  const [lastTransaction, setLastTransaction] = useState(null);
  const [scannerOpen, setScannerOpen] = useState(false);
  const [unknownBarcode, setUnknownBarcode] = useState('');
  const [unknownDialogOpen, setUnknownDialogOpen] = useState(false);

  useEffect(() => {
    async function load() {
      const [prods, cats] = await Promise.all([
        base44.entities.Product.filter({ is_active: true }),
        base44.entities.Category.list(),
      ]);
      setProducts(prods);
      setCategories(cats);
      setLoading(false);
    }
    load();
  }, []);

  useEffect(() => {
    barcodeInputRef.current?.focus();
  }, []);

  const filteredProducts = products.filter(p => {
    const matchSearch = p.name.toLowerCase().includes(search.toLowerCase()) || (p.barcode || '').includes(search);
    const matchCat = selectedCategory === 'all' || p.category_name === selectedCategory;
    return matchSearch && matchCat;
  });

  const handleBarcodeDetected = (barcode) => {
    const product = products.find(p => p.barcode === barcode);
    if (product) {
      addToCart(product);
      setScannerOpen(false);
      toast.success(`${product.name} ditambahkan ke keranjang`);
      setBarcodeInput('');
      barcodeInputRef.current?.focus();
    } else {
      setUnknownBarcode(barcode);
      setUnknownDialogOpen(true);
      toast.error('Barang Belum Ada');
      setScannerOpen(false);
      barcodeInputRef.current?.focus();
    }
  };

  const handleBarcodeSubmit = () => {
    const code = barcodeInput.trim();
    if (!code) return;
    handleBarcodeDetected(code);
  };

  const addToCart = (product) => {
    setCart(prev => {
      const existing = prev.find(item => item.product_id === product.id);
      if (existing) {
        if (existing.quantity >= product.stock) { toast.error('Stok tidak mencukupi'); return prev; }
        return prev.map(item =>
          item.product_id === product.id
            ? { ...item, quantity: item.quantity + 1, subtotal: (item.quantity + 1) * item.price }
            : item
        );
      }
      if (product.stock <= 0) { toast.error('Stok habis'); return prev; }
      return [...prev, {
        product_id: product.id,
        product_name: product.name,
        price: product.price,
        quantity: 1,
        subtotal: product.price,
      }];
    });
  };

  const updateQuantity = (productId, delta) => {
    setCart(prev =>
      prev.map(item => {
        if (item.product_id !== productId) return item;
        const product = products.find(p => p.id === productId);
        const newQty = item.quantity + delta;
        if (newQty <= 0) return null;
        if (newQty > (product?.stock || 0)) { toast.error('Stok tidak mencukupi'); return item; }
        return { ...item, quantity: newQty, subtotal: newQty * item.price };
      }).filter(Boolean)
    );
  };

  const removeFromCart = (productId) => {
    setCart(prev => prev.filter(item => item.product_id !== productId));
  };

  const cartTotal = cart.reduce((s, item) => s + item.subtotal, 0);

  const handlePayment = async () => {
    if (cart.length === 0) return;
    const paid = parseFloat(paymentAmount) || 0;
    if (paymentMethod === 'cash' && paid < cartTotal) { toast.error('Jumlah bayar kurang'); return; }
    setProcessing(true);

    const invoiceNumber = generateInvoiceNumber();
    const finalPaid = paymentMethod === 'cash' ? paid : cartTotal;

    const txn = await base44.entities.Transaction.create({
      invoice_number: invoiceNumber,
      items: cart,
      total: cartTotal,
      payment_amount: finalPaid,
      change_amount: paymentMethod === 'cash' ? finalPaid - cartTotal : 0,
      payment_method: paymentMethod,
      status: 'completed',
    });

    for (const item of cart) {
      const product = products.find(p => p.id === item.product_id);
      if (product) {
        await base44.entities.Product.update(item.product_id, { stock: product.stock - item.quantity });
      }
    }

    setLastTransaction({
      ...txn,
      invoice_number: invoiceNumber,
      items: cart,
      total: cartTotal,
      payment_amount: finalPaid,
      change_amount: paymentMethod === 'cash' ? finalPaid - cartTotal : 0,
      payment_method: paymentMethod,
    });

    const updatedProducts = await base44.entities.Product.filter({ is_active: true });
    setProducts(updatedProducts);
    setCart([]);
    setCartOpen(false);
    setPaymentOpen(false);
    setPaymentAmount('');
    setProcessing(false);
    setReceiptOpen(true);
    toast.success('Transaksi berhasil!');
  };

  const quickAmounts = [50000, 100000, 150000, 200000];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="flex flex-col space-y-4 pb-4">
      {/* Search + Scan */}
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Cari produk atau ketik barcode..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pl-10 rounded-xl"
          />
        </div>
        <button
          onClick={() => setScannerOpen(true)}
          className="h-10 w-10 rounded-xl bg-primary flex items-center justify-center flex-shrink-0 select-none active:scale-95 transition-transform"
          style={{ WebkitUserSelect: 'none' }}
        >
          <ScanLine className="h-5 w-5 text-primary-foreground" />
        </button>
      </div>

      {/* Input barcode untuk scanner pistol/keyboard */}
      <div className="flex gap-2">
        <Input
          ref={barcodeInputRef}
          placeholder="Scan barcode di sini..."
          value={barcodeInput}
          onChange={e => setBarcodeInput(e.target.value)}
          onKeyDown={e => {
            if (e.key === 'Enter') {
              e.preventDefault();
              handleBarcodeSubmit();
            }
          }}
          className="rounded-xl"
        />
        <button
          onClick={() => setScannerOpen(true)}
          className="h-10 w-10 rounded-xl bg-secondary border border-border flex items-center justify-center flex-shrink-0 select-none active:scale-95 transition-transform"
          style={{ WebkitUserSelect: 'none' }}
          aria-label="Scan barcode pakai kamera"
        >
          <ScanLine className="h-4 w-4 text-foreground" />
        </button>
      </div>

      {/* Category Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-1 -mx-1 px-1 scrollbar-hide">
        <button
          onClick={() => setSelectedCategory('all')}
          className={`px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-all select-none ${
            selectedCategory === 'all' ? 'bg-primary text-primary-foreground' : 'bg-secondary text-secondary-foreground'
          }`}
          style={{ WebkitUserSelect: 'none' }}
        >
          Semua
        </button>
        {categories.map(cat => (
          <button
            key={cat.id}
            onClick={() => setSelectedCategory(cat.name)}
            className={`px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-all select-none ${
              selectedCategory === cat.name ? 'bg-primary text-primary-foreground' : 'bg-secondary text-secondary-foreground'
            }`}
            style={{ WebkitUserSelect: 'none' }}
          >
            {cat.icon} {cat.name}
          </button>
        ))}
      </div>

      {/* Product Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
        {filteredProducts.map(product => (
          <button
            key={product.id}
            onClick={() => addToCart(product)}
            className="bg-card border border-border rounded-2xl p-3 text-left hover:shadow-md hover:border-primary/30 active:scale-95 transition-all duration-150 select-none"
            style={{ WebkitUserSelect: 'none', WebkitTapHighlightColor: 'transparent' }}
          >
            <h3 className="text-sm font-semibold leading-tight line-clamp-2 mb-1">{product.name}</h3>
            <p className="text-[10px] text-muted-foreground mb-1">{product.category_name || 'Lainnya'}</p>
            <p className="text-sm font-bold text-primary">{formatRupiah(product.price)}</p>
            <p className={`text-[10px] mt-0.5 ${product.stock <= 10 ? 'text-destructive font-medium' : 'text-muted-foreground'}`}>
              Stok: {product.stock}
            </p>
          </button>
        ))}
      </div>
      {filteredProducts.length === 0 && (
        <div className="text-center py-16 text-muted-foreground">
          <Package className="h-10 w-10 mx-auto mb-2 opacity-30" />
          <p className="text-sm">Produk tidak ditemukan</p>
        </div>
      )}

      {/* Floating Cart Button */}
      {cart.length > 0 && (
        <div className="fixed bottom-20 right-4 z-50" style={{ bottom: 'calc(env(safe-area-inset-bottom) + 4.5rem)' }}>
          <button
            onClick={() => setCartOpen(true)}
            className="flex items-center gap-2 bg-primary text-primary-foreground px-5 py-3 rounded-2xl shadow-xl font-semibold text-sm select-none active:scale-95 transition-transform"
            style={{ WebkitUserSelect: 'none' }}
          >
            <ShoppingCart className="h-5 w-5" />
            <span>{cart.length} item</span>
            <span className="font-bold">{formatRupiah(cartTotal)}</span>
          </button>
        </div>
      )}

      {/* Barcode Scanner */}
      {scannerOpen && (
        <BarcodeScanner
          onDetected={handleBarcodeDetected}
          onClose={() => setScannerOpen(false)}
        />
      )}

      <Dialog open={unknownDialogOpen} onOpenChange={setUnknownDialogOpen}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>Barang Belum Ada</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <p className="text-sm text-muted-foreground">
              Barcode <span className="font-mono">{unknownBarcode}</span> belum terdaftar.
            </p>
            <Button
              className="w-full rounded-xl"
              onClick={() => {
                setUnknownDialogOpen(false);
                navigate(`/produk?newBarcode=${encodeURIComponent(unknownBarcode)}`);
              }}
            >
              Tambah Barang Baru
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Cart Sheet */}
      <Sheet open={cartOpen} onOpenChange={setCartOpen}>
        <SheetContent side="bottom" className="rounded-t-3xl max-h-[85vh] flex flex-col" style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}>
          <SheetHeader className="pb-4 border-b border-border">
            <SheetTitle className="flex items-center gap-2">
              <ShoppingCart className="h-5 w-5 text-primary" /> Keranjang ({cart.length})
            </SheetTitle>
          </SheetHeader>

          <div className="flex-1 overflow-y-auto py-4 space-y-3">
            {cart.map(item => (
              <div key={item.product_id} className="bg-secondary/50 rounded-xl p-3">
                <div className="flex items-start justify-between mb-2">
                  <p className="text-sm font-medium flex-1">{item.product_name}</p>
                  <button
                    onClick={() => removeFromCart(item.product_id)}
                    className="text-muted-foreground hover:text-destructive transition-colors ml-2 select-none"
                    style={{ WebkitUserSelect: 'none' }}
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => updateQuantity(item.product_id, -1)}
                      className="h-8 w-8 rounded-lg bg-card border border-border flex items-center justify-center select-none"
                      style={{ WebkitUserSelect: 'none' }}
                    >
                      <Minus className="h-3 w-3" />
                    </button>
                    <span className="text-sm font-semibold w-6 text-center">{item.quantity}</span>
                    <button
                      onClick={() => updateQuantity(item.product_id, 1)}
                      className="h-8 w-8 rounded-lg bg-card border border-border flex items-center justify-center select-none"
                      style={{ WebkitUserSelect: 'none' }}
                    >
                      <Plus className="h-3 w-3" />
                    </button>
                  </div>
                  <p className="text-sm font-bold">{formatRupiah(item.subtotal)}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="border-t border-border pt-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-lg font-bold">Total</span>
              <span className="text-xl font-bold text-primary">{formatRupiah(cartTotal)}</span>
            </div>
            <Button
              className="w-full rounded-xl h-12 text-base font-semibold select-none"
              style={{ WebkitUserSelect: 'none' }}
              onClick={() => { setCartOpen(false); setPaymentOpen(true); setPaymentAmount(''); }}
            >
              Bayar
            </Button>
          </div>
        </SheetContent>
      </Sheet>

      {/* Payment Dialog */}
      <Dialog open={paymentOpen} onOpenChange={setPaymentOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Pembayaran</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="text-center py-2">
              <p className="text-sm text-muted-foreground">Total Pembayaran</p>
              <p className="text-3xl font-bold text-primary">{formatRupiah(cartTotal)}</p>
            </div>

            <div className="grid grid-cols-3 gap-2">
              {[
                { method: 'cash', icon: Banknote, label: 'Tunai' },
                { method: 'transfer', icon: CreditCard, label: 'Transfer' },
                { method: 'qris', icon: QrCode, label: 'QRIS' },
              ].map(({ method, icon: Icon, label }) => (
                <button
                  key={method}
                  onClick={() => setPaymentMethod(method)}
                  className={`p-3 rounded-xl border-2 flex flex-col items-center gap-1.5 transition-all select-none ${
                    paymentMethod === method ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/30'
                  }`}
                  style={{ WebkitUserSelect: 'none' }}
                >
                  <Icon className={`h-5 w-5 ${paymentMethod === method ? 'text-primary' : 'text-muted-foreground'}`} />
                  <span className="text-xs font-medium">{label}</span>
                </button>
              ))}
            </div>

            {paymentMethod === 'cash' && (
              <>
                <div>
                  <label className="text-sm font-medium mb-1.5 block">Jumlah Bayar</label>
                  <Input
                    type="number"
                    placeholder="Masukkan jumlah..."
                    value={paymentAmount}
                    onChange={e => setPaymentAmount(e.target.value)}
                    className="rounded-xl text-lg font-semibold h-12"
                    autoFocus
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {quickAmounts.map(amount => (
                    <button
                      key={amount}
                      onClick={() => setPaymentAmount(amount.toString())}
                      className="py-2 px-3 rounded-xl border border-border text-sm font-medium hover:bg-secondary transition-colors select-none"
                      style={{ WebkitUserSelect: 'none' }}
                    >
                      {formatRupiah(amount)}
                    </button>
                  ))}
                  <button
                    onClick={() => setPaymentAmount(cartTotal.toString())}
                    className="py-2 px-3 rounded-xl border-2 border-primary text-sm font-medium text-primary hover:bg-primary/5 transition-colors col-span-2 select-none"
                    style={{ WebkitUserSelect: 'none' }}
                  >
                    Uang Pas {formatRupiah(cartTotal)}
                  </button>
                </div>
                {parseFloat(paymentAmount) >= cartTotal && (
                  <div className="bg-primary/10 rounded-xl p-3 text-center">
                    <p className="text-sm text-muted-foreground">Kembalian</p>
                    <p className="text-xl font-bold text-primary">{formatRupiah(parseFloat(paymentAmount) - cartTotal)}</p>
                  </div>
                )}
              </>
            )}

            <Button
              className="w-full h-12 rounded-xl text-base font-semibold select-none"
              style={{ WebkitUserSelect: 'none' }}
              onClick={handlePayment}
              disabled={processing}
            >
              {processing ? 'Memproses...' : 'Konfirmasi Pembayaran'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Receipt */}
      {receiptOpen && lastTransaction && (
        <Receipt
          transaction={lastTransaction}
          onClose={() => setReceiptOpen(false)}
        />
      )}
    </div>
  );
}
import { useState, useEffect, useCallback } from 'react';
import { base44 } from '../api/base44Client';
import { formatRupiah } from '../lib/formatCurrency';
import { Calendar, ShoppingBag, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import PullToRefresh from '../components/PullToRefresh';
import moment from 'moment';

const COLORS = ['hsl(152, 60%, 36%)', 'hsl(38, 92%, 50%)', 'hsl(197, 37%, 24%)', 'hsl(43, 74%, 66%)', 'hsl(27, 87%, 67%)', 'hsl(340, 70%, 55%)'];

export default function Laporan() {
  const [transactions, setTransactions] = useState([]);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState('7days');

  const loadData = useCallback(async () => {
    const [txns, prods] = await Promise.all([
      base44.entities.Transaction.list('-created_date', 500),
      base44.entities.Product.list('-created_date', 200),
    ]);
    setTransactions(txns);
    setProducts(prods);
    setLoading(false);
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  const periodDays = { '7days': 7, '30days': 30, '90days': 90 };
  const days = periodDays[period] || 7;
  const startDate = moment().subtract(days, 'days').startOf('day');
  const periodTxns = transactions.filter(t => moment(t.created_date).isAfter(startDate));

  const totalRevenue = periodTxns.reduce((s, t) => s + (t.total || 0), 0);
  const avgTransaction = periodTxns.length ? totalRevenue / periodTxns.length : 0;

  const dailyData = Array.from({ length: Math.min(days, 14) }, (_, i) => {
    const day = moment().subtract(Math.min(days, 14) - 1 - i, 'days');
    const dayTxns = periodTxns.filter(t => moment(t.created_date).isSame(day, 'day'));
    return {
      date: day.format('DD/MM'),
      revenue: dayTxns.reduce((s, t) => s + (t.total || 0), 0),
      count: dayTxns.length,
    };
  });

  const productSales = {};
  periodTxns.forEach(txn => {
    txn.items?.forEach(item => {
      if (!productSales[item.product_name]) {
        productSales[item.product_name] = { name: item.product_name, revenue: 0, quantity: 0 };
      }
      productSales[item.product_name].revenue += item.subtotal || 0;
      productSales[item.product_name].quantity += item.quantity || 0;
    });
  });
  const topProducts = Object.values(productSales).sort((a, b) => b.revenue - a.revenue).slice(0, 5);

  const paymentBreakdown = {};
  const paymentLabels = { cash: 'Tunai', transfer: 'Transfer', qris: 'QRIS' };
  periodTxns.forEach(txn => {
    const method = paymentLabels[txn.payment_method] || txn.payment_method || 'Lainnya';
    paymentBreakdown[method] = (paymentBreakdown[method] || 0) + (txn.total || 0);
  });
  const pieData = Object.entries(paymentBreakdown).map(([name, value]) => ({ name, value }));

  const totalCost = periodTxns.reduce((s, txn) => {
    return s + (txn.items || []).reduce((ss, item) => {
      const product = products.find(p => p.name === item.product_name);
      return ss + ((product?.cost_price || 0) * (item.quantity || 0));
    }, 0);
  }, 0);
  const estimatedProfit = totalRevenue - totalCost;

  return (
    <PullToRefresh onRefresh={loadData}>
      <div className="space-y-5 pb-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold tracking-tight">Laporan</h1>
            <p className="text-muted-foreground text-sm mt-0.5">Analisis penjualan toko</p>
          </div>
          <Select value={period} onValueChange={setPeriod}>
            <SelectTrigger className="w-36 rounded-xl select-none" style={{ WebkitUserSelect: 'none' }}>
              <Calendar className="h-4 w-4 mr-1.5" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7days">7 Hari</SelectItem>
              <SelectItem value="30days">30 Hari</SelectItem>
              <SelectItem value="90days">90 Hari</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-card border border-border rounded-2xl p-4">
            <p className="text-xs text-muted-foreground">Total Pendapatan</p>
            <p className="text-lg font-bold mt-1">{formatRupiah(totalRevenue)}</p>
            <p className="text-xs text-muted-foreground mt-0.5">{periodTxns.length} transaksi</p>
          </div>
          <div className="bg-card border border-border rounded-2xl p-4">
            <p className="text-xs text-muted-foreground">Est. Keuntungan</p>
            <p className="text-lg font-bold mt-1 text-primary">{formatRupiah(estimatedProfit)}</p>
            <div className="flex items-center gap-0.5 mt-0.5">
              {estimatedProfit >= 0
                ? <ArrowUpRight className="h-3 w-3 text-primary" />
                : <ArrowDownRight className="h-3 w-3 text-destructive" />}
              <span className="text-xs text-muted-foreground">
                {totalRevenue > 0 ? ((estimatedProfit / totalRevenue) * 100).toFixed(1) : 0}% margin
              </span>
            </div>
          </div>
          <div className="bg-card border border-border rounded-2xl p-4">
            <p className="text-xs text-muted-foreground">Rata-rata Transaksi</p>
            <p className="text-lg font-bold mt-1">{formatRupiah(avgTransaction)}</p>
          </div>
          <div className="bg-card border border-border rounded-2xl p-4">
            <p className="text-xs text-muted-foreground">Total Item Terjual</p>
            <p className="text-lg font-bold mt-1">
              {periodTxns.reduce((s, t) => s + (t.items || []).reduce((ss, i) => ss + (i.quantity || 0), 0), 0)}
            </p>
          </div>
        </div>

        {/* Revenue Chart */}
        <div className="bg-card border border-border rounded-2xl p-4">
          <h2 className="font-semibold text-sm mb-3">Grafik Penjualan</h2>
          <div className="h-52">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={dailyData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="date" tick={{ fontSize: 10 }} />
                <YAxis tick={{ fontSize: 10 }} tickFormatter={v => `${(v / 1000).toFixed(0)}k`} />
                <Tooltip formatter={v => formatRupiah(v)} />
                <Bar dataKey="revenue" fill="hsl(var(--primary))" radius={[5, 5, 0, 0]} name="Pendapatan" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Payment Pie */}
        {pieData.length > 0 && (
          <div className="bg-card border border-border rounded-2xl p-4">
            <h2 className="font-semibold text-sm mb-3">Metode Pembayaran</h2>
            <div className="h-48">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={pieData} cx="50%" cy="50%" outerRadius={70} dataKey="value" label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`} labelLine={false}>
                    {pieData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                  </Pie>
                  <Tooltip formatter={v => formatRupiah(v)} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}

        {/* Top Products */}
        <div className="bg-card border border-border rounded-2xl p-4">
          <h2 className="font-semibold text-sm mb-3 flex items-center gap-2">
            <ShoppingBag className="h-4 w-4 text-primary" /> Produk Terlaris
          </h2>
          {topProducts.length > 0 ? (
            <div className="space-y-2">
              {topProducts.map((prod, i) => (
                <div key={prod.name} className="flex items-center gap-3 p-3 rounded-xl bg-secondary/30">
                  <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center text-xs font-bold text-primary flex-shrink-0">
                    #{i + 1}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{prod.name}</p>
                    <p className="text-xs text-muted-foreground">{prod.quantity} terjual</p>
                  </div>
                  <p className="text-sm font-bold text-primary">{formatRupiah(prod.revenue)}</p>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-center text-muted-foreground text-sm py-6">Belum ada data penjualan</p>
          )}
        </div>
      </div>
    </PullToRefresh>
  );
}
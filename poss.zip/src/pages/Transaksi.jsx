import { useState, useEffect, useCallback } from 'react';
import { base44 } from '../api/base44Client';
import { formatRupiah } from '../lib/formatCurrency';
import { Search, Eye, History, Banknote, CreditCard, QrCode, Printer } from 'lucide-react';
import { Input } from '../components/ui/input';
import { Button } from '../components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../components/ui/dialog';
import PullToRefresh from '../components/PullToRefresh';
import moment from 'moment';
import Receipt from '../components/Receipt';

const paymentIcons = { cash: Banknote, transfer: CreditCard, qris: QrCode };
const paymentLabels = { cash: 'Tunai', transfer: 'Transfer', qris: 'QRIS' };

export default function Transaksi() {
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [detailOpen, setDetailOpen] = useState(false);
  const [selectedTxn, setSelectedTxn] = useState(null);
  const [reprintOpen, setReprintOpen] = useState(false);

  const loadData = useCallback(async () => {
    const txns = await base44.entities.Transaction.list('-created_date', 200);
    setTransactions(txns);
    setLoading(false);
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  const filtered = transactions.filter(t =>
    (t.invoice_number || '').toLowerCase().includes(search.toLowerCase()) ||
    (t.customer_name || '').toLowerCase().includes(search.toLowerCase())
  );

  const openDetail = (txn) => {
    setSelectedTxn(txn);
    setDetailOpen(true);
  };

  const openReprint = (txn) => {
    setSelectedTxn(txn);
    setReprintOpen(true);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <PullToRefresh onRefresh={loadData}>
      <div className="space-y-4 pb-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight">Riwayat Transaksi</h1>
          <p className="text-muted-foreground text-sm mt-0.5">{transactions.length} transaksi</p>
        </div>

        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Cari invoice..." value={search} onChange={e => setSearch(e.target.value)} className="pl-10 rounded-xl" />
        </div>

        {/* Desktop table */}
        <div className="hidden md:block bg-card border border-border rounded-2xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border bg-secondary/50">
                  <th className="text-left text-xs font-semibold text-muted-foreground uppercase tracking-wider px-6 py-4">Invoice</th>
                  <th className="text-left text-xs font-semibold text-muted-foreground uppercase tracking-wider px-6 py-4">Tanggal</th>
                  <th className="text-left text-xs font-semibold text-muted-foreground uppercase tracking-wider px-6 py-4">Pembayaran</th>
                  <th className="text-right text-xs font-semibold text-muted-foreground uppercase tracking-wider px-6 py-4">Item</th>
                  <th className="text-right text-xs font-semibold text-muted-foreground uppercase tracking-wider px-6 py-4">Total</th>
                  <th className="text-right text-xs font-semibold text-muted-foreground uppercase tracking-wider px-6 py-4">Aksi</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(txn => {
                  const PayIcon = paymentIcons[txn.payment_method] || Banknote;
                  return (
                    <tr key={txn.id} className="border-b border-border last:border-0 hover:bg-secondary/30 transition-colors">
                      <td className="px-6 py-4"><p className="text-sm font-medium">{txn.invoice_number || '-'}</p></td>
                      <td className="px-6 py-4 text-sm text-muted-foreground">{moment(txn.created_date).format('DD/MM/YYYY HH:mm')}</td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <PayIcon className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm">{paymentLabels[txn.payment_method] || txn.payment_method}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm text-right">{txn.items?.length || 0}</td>
                      <td className="px-6 py-4 text-sm text-right font-semibold text-primary">{formatRupiah(txn.total)}</td>
                      <td className="px-6 py-4 text-right">
                        <div className="inline-flex items-center gap-1">
                          <Button variant="ghost" size="icon" className="h-8 w-8 select-none" onClick={() => openDetail(txn)}>
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8 select-none" onClick={() => openReprint(txn)}>
                            <Printer className="h-4 w-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Mobile card list */}
        <div className="md:hidden space-y-3">
          {filtered.map(txn => {
            const PayIcon = paymentIcons[txn.payment_method] || Banknote;
            return (
              <div
                key={txn.id}
                className="w-full bg-card border border-border rounded-2xl p-4 text-left hover:shadow-sm transition-shadow"
              >
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <p className="font-semibold text-sm">{txn.invoice_number || '-'}</p>
                    <p className="text-xs text-muted-foreground">{moment(txn.created_date).format('DD MMM YYYY, HH:mm')}</p>
                  </div>
                  <p className="text-base font-bold text-primary">{formatRupiah(txn.total)}</p>
                </div>
                <div className="flex items-center gap-3 mt-2 pt-2 border-t border-border">
                  <div className="flex items-center gap-1.5">
                    <PayIcon className="h-3.5 w-3.5 text-muted-foreground" />
                    <span className="text-xs text-muted-foreground">{paymentLabels[txn.payment_method] || txn.payment_method}</span>
                  </div>
                  <span className="text-xs text-muted-foreground">·</span>
                  <span className="text-xs text-muted-foreground">{txn.items?.length || 0} item</span>
                </div>
                <div className="flex gap-2 mt-3 pt-3 border-t border-border">
                  <Button variant="secondary" className="flex-1 rounded-xl h-9" onClick={() => openDetail(txn)}>
                    <Eye className="h-4 w-4 mr-1.5" /> Detail
                  </Button>
                  <Button variant="outline" className="flex-1 rounded-xl h-9" onClick={() => openReprint(txn)}>
                    <Printer className="h-4 w-4 mr-1.5" /> Reprint
                  </Button>
                </div>
              </div>
            );
          })}
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">
            <History className="h-10 w-10 mx-auto mb-2 opacity-30" />
            <p className="text-sm">Belum ada transaksi</p>
          </div>
        )}
      </div>

      {/* Detail Dialog */}
      <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Detail Transaksi</DialogTitle>
          </DialogHeader>
          {selectedTxn && (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <p className="text-sm font-mono text-muted-foreground">{selectedTxn.invoice_number}</p>
                <p className="text-sm text-muted-foreground">{moment(selectedTxn.created_date).format('DD/MM/YYYY HH:mm')}</p>
              </div>
              <div className="space-y-2">
                {selectedTxn.items?.map((item, i) => (
                  <div key={i} className="flex justify-between text-sm py-2 border-b border-border last:border-0">
                    <div>
                      <p className="font-medium">{item.product_name}</p>
                      <p className="text-xs text-muted-foreground">{item.quantity} x {formatRupiah(item.price)}</p>
                    </div>
                    <p className="font-medium">{formatRupiah(item.subtotal)}</p>
                  </div>
                ))}
              </div>
              <div className="bg-secondary/50 rounded-xl p-4 space-y-2">
                <div className="flex justify-between font-bold text-lg">
                  <span>Total</span>
                  <span className="text-primary">{formatRupiah(selectedTxn.total)}</span>
                </div>
                <div className="flex justify-between text-sm text-muted-foreground">
                  <span>Pembayaran</span>
                  <span>{paymentLabels[selectedTxn.payment_method]}</span>
                </div>
                {selectedTxn.payment_method === 'cash' && (
                  <>
                    <div className="flex justify-between text-sm">
                      <span>Bayar</span>
                      <span>{formatRupiah(selectedTxn.payment_amount)}</span>
                    </div>
                    <div className="flex justify-between text-sm font-semibold">
                      <span>Kembalian</span>
                      <span>{formatRupiah(selectedTxn.change_amount)}</span>
                    </div>
                  </>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {reprintOpen && selectedTxn && (
        <Receipt
          transaction={selectedTxn}
          onClose={() => setReprintOpen(false)}
        />
      )}
    </PullToRefresh>
  );
}
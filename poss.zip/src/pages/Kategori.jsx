import { useState, useEffect, useCallback } from 'react';
import { base44 } from '../api/base44Client';
import { Plus, Pencil, Trash2, Tags } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../components/ui/dialog';
import { Label } from '../components/ui/label';
import { toast } from 'sonner';
import PullToRefresh from '../components/PullToRefresh';

export default function Kategori() {
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ name: '', icon: '' });

  const loadData = useCallback(async () => {
    const cats = await base44.entities.Category.list();
    setCategories(cats);
    setLoading(false);
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  const openAdd = () => {
    setEditing(null);
    setForm({ name: '', icon: '' });
    setDialogOpen(true);
  };

  const openEdit = (cat) => {
    setEditing(cat);
    setForm({ name: cat.name, icon: cat.icon || '' });
    setDialogOpen(true);
  };

  const handleSave = async () => {
    if (!form.name) { toast.error('Nama wajib diisi'); return; }
    if (editing) {
      await base44.entities.Category.update(editing.id, form);
      toast.success('Kategori diperbarui');
    } else {
      await base44.entities.Category.create(form);
      toast.success('Kategori ditambahkan');
    }
    setDialogOpen(false);
    await loadData();
  };

  const handleDelete = async (id) => {
    if (!confirm('Hapus kategori ini?')) return;
    await base44.entities.Category.delete(id);
    toast.success('Kategori dihapus');
    await loadData();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <PullToRefresh onRefresh={loadData}>
      <div className="space-y-4 pb-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold tracking-tight">Kategori</h1>
            <p className="text-muted-foreground text-sm mt-0.5">{categories.length} kategori</p>
          </div>
          <Button
            onClick={openAdd}
            className="rounded-xl select-none"
            style={{ WebkitUserSelect: 'none' }}
          >
            <Plus className="h-4 w-4 mr-1.5" /> Tambah
          </Button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          {categories.map(cat => (
            <div key={cat.id} className="bg-card border border-border rounded-2xl p-4 hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-2xl">{cat.icon || '📦'}</span>
                  <h3 className="font-semibold text-sm">{cat.name}</h3>
                </div>
                <div className="flex gap-1">
                  <button
                    onClick={() => openEdit(cat)}
                    className="h-7 w-7 rounded-lg flex items-center justify-center hover:bg-secondary transition-colors select-none"
                    style={{ WebkitUserSelect: 'none' }}
                  >
                    <Pencil className="h-3.5 w-3.5 text-muted-foreground" />
                  </button>
                  <button
                    onClick={() => handleDelete(cat.id)}
                    className="h-7 w-7 rounded-lg flex items-center justify-center hover:bg-destructive/10 transition-colors select-none"
                    style={{ WebkitUserSelect: 'none' }}
                  >
                    <Trash2 className="h-3.5 w-3.5 text-destructive" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {categories.length === 0 && (
          <div className="text-center py-16 text-muted-foreground">
            <Tags className="h-12 w-12 mx-auto mb-3 opacity-30" />
            <p className="text-sm">Belum ada kategori</p>
          </div>
        )}
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>{editing ? 'Edit Kategori' : 'Tambah Kategori'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Nama Kategori *</Label>
              <Input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} className="rounded-xl mt-1" />
            </div>
            <div>
              <Label>Icon (emoji)</Label>
              <Input value={form.icon} onChange={e => setForm({ ...form, icon: e.target.value })} className="rounded-xl mt-1" placeholder="Contoh: 🍞" />
            </div>
            <Button
              className="w-full rounded-xl select-none"
              style={{ WebkitUserSelect: 'none' }}
              onClick={handleSave}
            >
              {editing ? 'Simpan' : 'Tambah'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </PullToRefresh>
  );
}
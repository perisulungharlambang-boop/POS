// Client data lokal: baca/mutasi dari public/entities/*.json + persist ke localStorage (mode offline)

const STORAGE_KEY = 'pos_offline_entities_v2';

const ENTITY_KEYS = {
  Product: 'Product',
  Category: 'Category',
  Transaction: 'Transaction',
};

function isJsonSchemaStub(parsed) {
  return (
    parsed &&
    typeof parsed === 'object' &&
    !Array.isArray(parsed) &&
    parsed.type === 'object' &&
    parsed.properties
  );
}

async function loadJsonFile(entityKey) {
  const res = await fetch(`/entities/${entityKey}.json`);
  if (!res.ok) return [];
  const parsed = await res.json();
  if (Array.isArray(parsed)) return parsed;
  if (isJsonSchemaStub(parsed)) return [];
  return [];
}

let cache = null;
let initPromise = null;

function persist() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(cache));
  } catch (e) {
    console.warn('Tidak bisa simpan ke localStorage:', e);
  }
}

async function ensureInit() {
  if (cache) return;
  if (initPromise) {
    await initPromise;
    return;
  }
  initPromise = (async () => {
    let fromDisk = null;
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) fromDisk = JSON.parse(raw);
    } catch (_) {
      fromDisk = null;
    }
    if (
      fromDisk &&
      Array.isArray(fromDisk.Product) &&
      Array.isArray(fromDisk.Category) &&
      Array.isArray(fromDisk.Transaction)
    ) {
      cache = fromDisk;
      return;
    }
    const [products, categories, transactions] = await Promise.all([
      loadJsonFile('Product'),
      loadJsonFile('Category'),
      loadJsonFile('Transaction'),
    ]);
    cache = {
      Product: products,
      Category: categories,
      Transaction: transactions,
    };
    persist();
  })();
  await initPromise;
}

function sortRows(rows, sortField) {
  if (!sortField || !rows.length) return [...rows];
  const desc = sortField.startsWith('-');
  const field = desc ? sortField.slice(1) : sortField;
  const copy = [...rows];
  copy.sort((a, b) => {
    const av = a[field];
    const bv = b[field];
    if (av == null && bv == null) return 0;
    if (av == null) return 1;
    if (bv == null) return -1;
    let cmp = 0;
    if (typeof av === 'number' && typeof bv === 'number') cmp = av - bv;
    else cmp = String(av).localeCompare(String(bv));
    return desc ? -cmp : cmp;
  });
  return copy;
}

function findIndexById(rows, id) {
  return rows.findIndex((r) => String(r.id) === String(id));
}

function makeEntityApi(entityName) {
  const key = ENTITY_KEYS[entityName];
  if (!key) {
    throw new Error(`Entity tidak dikenal: ${entityName}`);
  }

  return {
    list: async (sortField, limit) => {
      await ensureInit();
      let rows = sortRows(cache[key], sortField);
      if (typeof limit === 'number' && limit > 0) rows = rows.slice(0, limit);
      return rows;
    },

    filter: async (criteria) => {
      await ensureInit();
      let rows = [...cache[key]];
      if (criteria && typeof criteria === 'object') {
        for (const [k, v] of Object.entries(criteria)) {
          rows = rows.filter((r) => r[k] === v);
        }
      }
      return rows;
    },

    create: async (data) => {
      await ensureInit();
      const now = new Date().toISOString();
      const id =
        data.id != null && data.id !== ''
          ? data.id
          : typeof crypto !== 'undefined' && crypto.randomUUID
            ? crypto.randomUUID()
            : `id-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
      const row = {
        ...data,
        id,
        created_date: data.created_date ?? now,
        updated_date: now,
      };
      cache[key].push(row);
      persist();
      return row;
    },

    update: async (id, data) => {
      await ensureInit();
      const idx = findIndexById(cache[key], id);
      if (idx === -1) throw new Error(`Baris tidak ditemukan: ${id}`);
      const now = new Date().toISOString();
      cache[key][idx] = {
        ...cache[key][idx],
        ...data,
        id: cache[key][idx].id,
        updated_date: now,
      };
      persist();
      return cache[key][idx];
    },

    delete: async (id) => {
      await ensureInit();
      const before = cache[key].length;
      cache[key] = cache[key].filter((r) => String(r.id) !== String(id));
      persist();
      if (cache[key].length === before) throw new Error(`Baris tidak ditemukan: ${id}`);
    },
  };
}

export const base44 = {
  entity: (name) => {
    const api = makeEntityApi(name);
    return { list: (...args) => api.list(...args) };
  },

  entities: {
    Product: makeEntityApi('Product'),
    Category: makeEntityApi('Category'),
    Transaction: makeEntityApi('Transaction'),
  },

  user: {
    me: async () => ({ name: 'Pak Ferry', role: 'Owner' }),
  },

  auth: {
    me: async () => ({
      id: 'offline-user',
      name: 'Pak Ferry',
      role: 'Owner',
      email: 'offline@local',
    }),
    logout: (redirectUrl) => {
      try {
        localStorage.removeItem('base44_access_token');
        localStorage.removeItem('token');
      } catch (_) {
        /* ignore */
      }
      if (typeof redirectUrl === 'string' && redirectUrl) {
        window.location.href = redirectUrl;
      }
    },
    redirectToLogin: (href) => {
      window.location.href = typeof href === 'string' && href ? href : '/';
    },
  },
};
